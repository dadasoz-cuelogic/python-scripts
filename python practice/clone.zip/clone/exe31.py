print "You enetred a dark rooms with two doors.Do you go through door #1 or do or #2"
door=raw_input(">")
if door=="1":
	print "There is a gaint bear here eating a cheese cake.What do you do?"
	print"1.Take a cake."
	print "2.Scream at the bear"
	bear=raw_input(">")
	if bear=="1":
		print "The bear eats your face off.Good job!"
	elif bear=="2":
		print"The bears eats your legs"
	else:
		print"Well,doin %s is probably.Bear runs Away"%(bear)
elif door== "2":
	print "You stare the endless abyss at Cr"
	print "1.Blueberrries"
	print "2.Yellow Jacket clothes spin"
	print "3.Understanding revovlers yelling melodies"
insanity=raw_input(">")
if insanity=="1" or insanity=="2":
	print "Your body survives powered by a mind of jello..Goodjob!!!!"
else:print "You stumble around and fall on knife and die.GoodJob!!!!!!"
