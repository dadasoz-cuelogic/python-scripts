people=20
cats=30
dogs=15
if people<cats:
	print "Cats:%rTOO many cats"%(cats)
if people>cats:
	print "CAts:%rNo many cats"%(cats)
if people<dogs:
	print "World is drooled"
if people>dogs:
	print "the wolrd is dry"
dogs+=5
if people>=dogs:
	print "People are greater than dogs"
if people<=dogs:
	print "People are less than or equal to dogs"
if people==dogs:
	print "People are dogs"

