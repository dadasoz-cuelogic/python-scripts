the_count=[1,2,3,4,5,6]
fruit=['apple','b','c']
for number in the_count:
	print"this is count %d number"
for fruit in fruit:
	print "A fruit of type %s"%fruit
for i in the_count:
	print "I got %r"% i
elements=[]
for i in range(0,6):
	print "Adding %d to the list "% i
	elements.append(i)
for i in elements:
	print "Element was %d"% i
