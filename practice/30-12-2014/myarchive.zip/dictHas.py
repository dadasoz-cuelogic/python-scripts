dict = {'Name': 'Zara', 'Age': 7,"users":{"name":"nishant"}}

print "Value : %s" %  dict.has_key('Age')
print "Value : %s" %  dict.has_key('Sex')
print "Value : %s" %  dict.has_key('name')
print "Value : %s" %  "name" in dict.keys()